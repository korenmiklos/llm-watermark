// Port of codedthinking/llm-watermark src/lib/* to a plain browser module.
// prf.ts, gamma.ts, sampler.ts, detector.ts, trigram.ts, step.ts,
// candidates.ts and wash.ts, unchanged in behaviour; wash re-tuned for the
// 9x Academic navy ground.

export const DOMAIN_WATERMARK = 0n;
export const DOMAIN_PLAIN = 1n;
const MASK64 = (1n << 64n) - 1n;
const GOLDEN = 0x9e3779b97f4a7c15n;

export function randomKeyBytes() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return bytes;
}
export function bytesToHex(bytes) {
  return [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('');
}
export function hexToBytes(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return bytes;
}
export function importHmacKey(bytes) {
  return crypto.subtle.importKey('raw', bytes, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
}
export function watermarkWindow(history, k, bosId) {
  const window = [];
  for (let i = history.length - k; i < history.length; i++) window.push(i < 0 ? bosId : history[i]);
  return window;
}
export async function windowDigest(key, windowIds) {
  const msg = new Uint8Array(windowIds.length * 4);
  const view = new DataView(msg.buffer);
  windowIds.forEach((id, i) => view.setUint32(i * 4, id, true));
  return new Uint8Array(await crypto.subtle.sign('HMAC', key, msg));
}
function splitmix64(state) {
  const next = (state + GOLDEN) & MASK64;
  let z = next;
  z = ((z ^ (z >> 30n)) * 0xbf58476d1ce4e5b9n) & MASK64;
  z = ((z ^ (z >> 27n)) * 0x94d049bb133111ebn) & MASK64;
  return [z ^ (z >> 31n), next];
}
function rotl32(x, bits) {
  return ((x << bits) | (x >>> (32 - bits))) >>> 0;
}
export function rngFromDigest(digest, domain) {
  const view = new DataView(digest.buffer, digest.byteOffset, digest.byteLength);
  const u0 = view.getBigUint64(0, true);
  const u1 = view.getBigUint64(8, true);
  const seed = (u0 ^ ((domain + 1n) * GOLDEN)) & MASK64;
  const [z0, mid] = splitmix64(seed);
  const [z1] = splitmix64((mid ^ u1) & MASK64);
  let s0 = Number(z0 & 0xffffffffn) >>> 0;
  let s1 = Number((z0 >> 32n) & 0xffffffffn) >>> 0;
  let s2 = Number(z1 & 0xffffffffn) >>> 0;
  let s3 = Number((z1 >> 32n) & 0xffffffffn) >>> 0;
  if ((s0 | s1 | s2 | s3) === 0) s3 = 1;
  return () => {
    const out = Math.imul(rotl32(Math.imul(s1, 5), 7), 9) >>> 0;
    const t = (s1 << 9) >>> 0;
    s2 = (s2 ^ s0) >>> 0;
    s3 = (s3 ^ s1) >>> 0;
    s1 = (s1 ^ s2) >>> 0;
    s0 = (s0 ^ s3) >>> 0;
    s2 = (s2 ^ t) >>> 0;
    s3 = rotl32(s3, 11);
    const u = (out >>> 8) * 2 ** -24;
    return Math.min(Math.max(u, 2 ** -24), 1 - 2 ** -24);
  };
}
export function drawRVector(rng, size) {
  const r = new Float64Array(size);
  for (let i = 0; i < size; i++) r[i] = rng();
  return r;
}

/* ---- gamma ---- */
const LANCZOS = [
  676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059,
  12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7,
];
export function lgamma(x) {
  if (x < 0.5) return Math.log(Math.PI / Math.sin(Math.PI * x)) - lgamma(1 - x);
  const g = x - 1;
  let a = 0.99999999999980993;
  const t = g + 7.5;
  for (let i = 0; i < LANCZOS.length; i++) a += LANCZOS[i] / (g + i + 1);
  return 0.5 * Math.log(2 * Math.PI) + (g + 0.5) * Math.log(t) - t + Math.log(a);
}
function lowerSeries(a, x) {
  let term = 1 / a;
  let sum = term;
  let n = a;
  for (let i = 0; i < 10000; i++) {
    n += 1;
    term *= x / n;
    sum += term;
    if (Math.abs(term) < Math.abs(sum) * 1e-16) break;
  }
  return sum * Math.exp(-x + a * Math.log(x) - lgamma(a));
}
function upperContinuedFraction(a, x) {
  const tiny = 1e-300;
  let b = x + 1 - a;
  let c = 1 / tiny;
  let d = 1 / b;
  let h = d;
  for (let i = 1; i < 10000; i++) {
    const an = -i * (i - a);
    b += 2;
    d = an * d + b;
    if (Math.abs(d) < tiny) d = tiny;
    c = b + an / c;
    if (Math.abs(c) < tiny) c = tiny;
    d = 1 / d;
    const del = d * c;
    h *= del;
    if (Math.abs(del - 1) < 1e-16) break;
  }
  return h * Math.exp(-x + a * Math.log(x) - lgamma(a));
}
export function gammaQ(a, x) {
  if (x <= 0) return 1;
  return x < a + 1 ? 1 - lowerSeries(a, x) : upperContinuedFraction(a, x);
}

/* ---- sampler ---- */
export const sampleWatermarked = (p, digest) => {
  const r = drawRVector(rngFromDigest(digest, DOMAIN_WATERMARK), p.length);
  let best = -1;
  let bestScore = -Infinity;
  for (let i = 0; i < p.length; i++) {
    if (p[i] <= 0) continue;
    const score = Math.log(r[i]) / p[i];
    if (score > bestScore) {
      bestScore = score;
      best = i;
    }
  }
  return { tokenId: best, r };
};

/* ---- detector ---- */
export function contribution(r) {
  return -Math.log(1 - r);
}
export function summarize(tokens) {
  const n = tokens.length;
  const score = tokens.reduce((s, t) => s + t.contribution, 0);
  const pValue = n === 0 ? 1 : Math.max(gammaQ(n, score), 1e-300);
  const z = n === 0 ? 0 : (score - n) / Math.sqrt(n);
  const log10InvP = Math.min(Math.log10(1 / pValue), 300);
  return { tokens, n, score, pValue, z, log10InvP };
}
export function shannonEntropy(p) {
  let h = 0;
  for (let i = 0; i < p.length; i++) if (p[i] > 0) h -= p[i] * Math.log(p[i]);
  return h;
}

/* ---- trigram ---- */
export const BOS = '<bos>';
export const EOS = '<eos>';
const W_TRI = 0.7;
const W_BI = 0.25;
const W_UNI = 0.05;

export function prepareModel(json) {
  return {
    ...json,
    bosId: json.vocab.indexOf(BOS),
    eosId: json.vocab.indexOf(EOS),
    unigramTotal: json.unigram.reduce((a, b) => a + b, 0),
  };
}
export async function loadModel(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`model fetch failed: ${res.status}`);
  return prepareModel(await res.json());
}
export function probabilities(model, w1, w2, temperature = 1) {
  const size = model.vocab.length;
  const p = new Float64Array(size);
  const tri = model.trigram[`${w1},${w2}`];
  const bi = model.bigram[String(w2)];
  const weightSum = W_UNI + (tri ? W_TRI : 0) + (bi ? W_BI : 0);
  const add = (entry, weight) => {
    let total = 0;
    for (const c of entry.counts) total += c;
    for (let j = 0; j < entry.ids.length; j++)
      p[entry.ids[j]] += (weight / weightSum) * (entry.counts[j] / total);
  };
  if (tri) add(tri, W_TRI);
  if (bi) add(bi, W_BI);
  const uniWeight = W_UNI / weightSum;
  for (let i = 0; i < size; i++) p[i] += uniWeight * (model.unigram[i] / model.unigramTotal);
  if (temperature !== 1) {
    let z = 0;
    for (let i = 0; i < size; i++) {
      p[i] = p[i] > 0 ? p[i] ** (1 / temperature) : 0;
      z += p[i];
    }
    for (let i = 0; i < size; i++) p[i] /= z;
  }
  return p;
}
export function tokenize(text) {
  return text.match(/[A-Za-z']+|[.,!?;:"]/g) ?? [];
}
export function knownIds(model, text) {
  const index = new Map(model.vocab.map((t, i) => [t, i]));
  return tokenize(text)
    .map((t) => index.get(t))
    .filter((id) => id !== undefined);
}

/* ---- step ---- */
export async function nextStep(model, key, history, k, temperature, sampler) {
  const w2 = history.length >= 1 ? history[history.length - 1] : model.bosId;
  const w1 = history.length >= 2 ? history[history.length - 2] : model.bosId;
  const probs = probabilities(model, w1, w2, temperature);
  const digest = await windowDigest(key, watermarkWindow(history, k, model.bosId));
  const { tokenId, r } = sampler(probs, digest);
  return { tokenId, probs, r, entropy: shannonEntropy(probs) };
}

/* ---- candidates ---- */
export function topCandidates(model, probs, r, winnerId, count = 12) {
  const picked = [];
  const taken = new Set();
  for (let n = 0; n < count; n++) {
    let best = -1;
    let bestP = 0;
    for (let i = 0; i < probs.length; i++) {
      if (probs[i] > bestP && !taken.has(i)) {
        bestP = probs[i];
        best = i;
      }
    }
    if (best < 0) break;
    taken.add(best);
    picked.push(best);
  }
  if (!taken.has(winnerId) && picked.length > 0) picked[picked.length - 1] = winnerId;
  return picked.map((id) => ({
    id,
    text: model.vocab[id],
    p: probs[id],
    r: r[id],
    score: Math.log(r[id]) / probs[id],
    winner: id === winnerId,
  }));
}

/* ---- wash: log10(1/p) as the window's background.
   Same construction as wash.ts, re-based on the 9x navy floor: teal at 0,
   navy in the middle, brand red past 6. ---- */
// One hue, one meaning: red is evidence. The window starts on the faint
// lavender panel (#F2F1FA, no signal) and saturates toward brand red as
// log10(1/p) climbs. Ink and grey stay chrome; they never carry the statistic.
const GROUND = [242, 241, 250];
const RED = [230, 30, 37];
const TINT = 0.12;
function mix(a, b, t) {
  return a.map((v, i) => v + (b[i] - v) * t);
}
export function washFraction(log10InvP) {
  return Math.min(Math.max(log10InvP / 6, 0), 1);
}
export function washColor(log10InvP) {
  const t = washFraction(log10InvP);
  const rgb = mix(GROUND, mix(GROUND, RED, TINT), t);
  return `rgb(${rgb.map((v) => Math.round(v)).join(', ')})`;
}

/* ---- Fallback model, used only until public/model.json is supplied.
   Same shape as the build script's output; counted from a short corpus. ---- */
const CORPUS = `Once upon a time there was a little girl named Lily . She loved to play in the garden with her dog .
Once upon a time a small boy found a shiny stone near the river . He put it in his pocket and ran home .
The little girl smiled and said , I want to share my apple with you . Her friend was very happy .
One day the sun was warm and the sky was blue . Lily and her dog walked to the big tree by the river .
The boy asked his mother , can I keep the stone ? His mother smiled and said yes , you can keep it .
Lily saw a bird in the tree . The bird sang a happy song and she began to dance in the garden .
They played all day until the sun went down . Then they walked home together and had a warm dinner .
The dog barked at the little bird but the bird was not afraid . It sang again and flew away .
Her mother said , it is time to sleep now . Lily said good night to her dog and closed her eyes .
The next day the boy came to the garden with the shiny stone . He gave it to Lily and she smiled .
She put the stone under the big tree so they could find it again . It was their little secret .
Every day after that they met by the river and told each other stories about the stone and the bird .`;

export function fallbackModel() {
  const sentences = CORPUS.split('\n').map((s) => s.trim()).filter(Boolean);
  const vocab = [BOS, EOS];
  const index = new Map(vocab.map((t, i) => [t, i]));
  const id = (tok) => {
    if (!index.has(tok)) {
      index.set(tok, vocab.length);
      vocab.push(tok);
    }
    return index.get(tok);
  };
  const seqs = sentences.map((s) => [0, 0, ...tokenize(s).map(id), 1]);
  const unigram = [];
  const bigram = {};
  const trigram = {};
  const bump = (table, keyStr, tokenId) => {
    const entry = (table[keyStr] ??= { ids: [], counts: [] });
    const at = entry.ids.indexOf(tokenId);
    if (at < 0) {
      entry.ids.push(tokenId);
      entry.counts.push(1);
    } else entry.counts[at] += 1;
  };
  for (const seq of seqs) {
    for (let t = 2; t < seq.length; t++) {
      const y = seq[t];
      unigram[y] = (unigram[y] ?? 0) + 1;
      bump(bigram, String(seq[t - 1]), y);
      bump(trigram, `${seq[t - 2]},${seq[t - 1]}`, y);
    }
  }
  for (let i = 0; i < vocab.length; i++) unigram[i] ??= 1;
  return prepareModel({ vocab, unigram, bigram, trigram });
}
