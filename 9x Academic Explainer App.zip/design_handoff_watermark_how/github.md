repo: codedthinking/llm-watermark
branch: main

## Last sync
date: 2026-08-12T09:20:00Z

### Updated in this project
- Recreated the Demo and Explainer screens as one Design Component.
- Reskinned in the Coded Thinking / koren.dev light palette (red accent, navy headings, Brockmann + DM Mono).
- Ported src/lib/* (PRF, sampler, detector, gamma, trigram) to a browser module — real statistics, no build step.
- Falls back to a small built-in trigram model until public/model.json is supplied.

## Screen map
| Screen | Repo files |
|---|---|
| Watermark Demo.dc.html (demo route) | src/App.tsx, src/pages/Demo.tsx, src/components/PromptBar.tsx, GenerationPane.tsx, CandidateList.tsx, ControlSentence.tsx, ScrubNumber.tsx, TryThis.tsx, src/hooks/useGeneration.ts, src/index.css |
| Watermark Demo.dc.html (#/explainer route) | src/pages/Explainer.tsx, src/App.tsx |
| watermark.js | src/lib/prf.ts, sampler.ts, detector.ts, gamma.ts, trigram.ts, step.ts, candidates.ts, wash.ts |
