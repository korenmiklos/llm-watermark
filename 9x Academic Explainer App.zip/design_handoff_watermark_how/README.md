# Handoff: watermark.how — light reskin of the llm-watermark demo

## Overview
A rebrand and light-mode reskin of `codedthinking/llm-watermark`. The app keeps its two
existing routes — the interactive Demo and the `#/explainer` notes — and restyles them in the
Coded Thinking / koren.dev identity, under a new product name: **watermark.how**, "by The 9x
Academic". The demo copy gains an EU AI Act framing paragraph and an SEO-shaped H1.

Nothing about the scheme, the sampler, the detector or the statistics changed. This is
presentation plus three copy blocks.

## About the design files
The files in this bundle are **design references written in HTML** — a prototype of the intended
look and behaviour, not production code to paste in. The target codebase is the existing React +
TypeScript + Tailwind v4 Vite app; implement the design there with its established patterns
(the `@theme` block in `src/index.css`, the existing components under `src/components/`).

`watermark.js` in this bundle is a plain-JS port of `src/lib/*` made only so the prototype could
run standalone. **Do not merge it** — the repo's TypeScript modules are the source of truth and
are unchanged.

## Fidelity
**High-fidelity.** Exact colours, type, spacing and interactions are specified below. Recreate
pixel-for-pixel using Tailwind theme tokens rather than hard-coded hex where a token exists.

---

## Design tokens

Replace the `@theme` block in `src/index.css`:

| Token | Old | New | Meaning |
|---|---|---|---|
| `--color-ground` | `#eef0f2` | `#F2F1FA` | figure ground — the generation window at zero evidence |
| `--color-ink` | `#16181c` | `#232324` | body text, caret, scale marker |
| `--color-accent` | `#2b3fa8` | `#E61E25` | brand red — actions, links, AND the evidence statistic |
| `--color-navy` | — | `#1D1D40` | headings |
| `--color-slate` | — | `#5D5A88` | standfirst / long-form secondary text |
| `--color-grey` | — | `#9795B5` | meta copy, captions, placeholders |
| `--color-line` | — | `#D4D2E3` | borders, dividers |
| `--color-sage` | `#7c9a72` | *(removed)* | |
| `--color-brick` | `#a8514b` | *(removed)* | |
| `--font-sans` | IBM Plex Sans | `'Brockmann', 'Helvetica Neue', Arial, sans-serif` | |
| `--font-heading` | IBM Plex Sans Condensed | `'Brockmann', ...` (same as sans) | |
| `--font-mono` | IBM Plex Mono | `'DM Mono', ui-monospace, monospace` | |

**Colour rule — every colour has one job.** Red is evidence, at every scale (window wash, token
tint, candidate dot) and is also the action colour. Ink is measurement chrome (caret, decade
marker) so the thing reading the scale is never mistaken for evidence. Grey/line is meta and
structure. There is no second accent hue; sage and brick are gone.

Radii: 2px (generation window, token tint), 6px (candidate dropdown), 4px (hover readout).
Shadow: `4px 10px 35px rgba(151,149,181,0.30)` — dropdown only.
Motion: 180ms `cubic-bezier(.4,0,.2,1)` for hovers; the existing 500ms wash and 300ms marker
transitions are unchanged.

### Fonts
Brockmann, self-hosted (woff2, weights 400/500/600/700 + 400 italic) — bundled here under
`fonts/`, originally from the Coded Thinking design system. DM Mono from Google Fonts:
`https://fonts.googleapis.com/css2?family=DM+Mono:ital,wght@0,400;0,500;1,400&display=swap`.

---

## The wash (`src/lib/wash.ts`)

Single-hue ramp instead of the old sage → ground → brick three-stop:

```ts
const GROUND = [242, 241, 250];   // #F2F1FA
const RED    = [230, 30, 37];     // #E61E25
const TINT   = 0.12;

export function washFraction(log10InvP: number) {
  return Math.min(Math.max(log10InvP / 6, 0), 1);       // unchanged
}
export function washColor(log10InvP: number) {
  const rgb = mix(GROUND, mix(GROUND, RED, TINT), washFraction(log10InvP));
  return \`rgb(\${rgb.map(v => Math.round(v)).join(', ')})\`;
}
```

Per-token tint (`GenerationPane.tsx`): `rgba(230, 30, 37, min(0.42, 0.09 * contribution))`
(was `rgba(168,81,75, min(0.5, 0.11 * c))`).
Candidate dot (`CandidateList.tsx`): `rgba(230, 30, 37, r)`.
Winner row: `rgba(230,30,37,0.10)` (Tailwind `bg-accent/10` already gives this).

---

## Screens

### 1. Demo (`#/`, `src/pages/Demo.tsx`)

Column: `mx-auto w-full max-w-3xl`, page padding `px-5 py-10`. Unchanged.

**Header (copy changes).** In order:
1. Kicker — DM Mono 12px/500, uppercase, tracking .18em, `#9795B5`: "Interactive explainer"
2. **H1** — Brockmann 700, 44px, line-height 1.15, tracking -0.02em, `#1D1D40`, max-width 672px:
   *"How does AI watermarking work?"*  (was "A watermark you can't see, but can measure")
3. **Standfirst** (new) — 22px/1.4, `#5D5A88`, margin-top 14px:
   *"A watermark you can't see, but can measure."*
4. **Framing paragraph** (new) — 17px/1.75, `#232324`, margin-top 26px, max-width 65ch:
   *"The EU AI Act obliges providers to mark AI-generated content so that it can be detected as
   machine-made. Text is the hard case: there are no pixels to perturb, only word choices. The
   scheme below is the one most often proposed for it, running live in this page."*
5. Existing intro paragraph — unchanged text, 17px/1.75, `#232324`, margin-top 16px.
6. Mono attribution line — DM Mono 12px, `#9795B5`: unchanged text.

**Figure** — `flex flex-col gap-[14px]`, margin-top 38px. Structure unchanged.

- **PromptBar**: play/pause 40px circle, `#E61E25`, white glyph, hover `#C41A20`. Prompt input:
  transparent, 1px bottom border `#D4D2E3`, DM Mono 14px, `#232324`, placeholder `#9795B5`,
  focus border `#E61E25`. "step" / "reset": DM Mono 12px `#9795B5`, hover `#E61E25`.
- **GenerationPane**: min-height 384px, 1px border `#D4D2E3`, radius 2px, background = wash.
  Left rail 28px, right border `#D4D2E3`, decade labels 0–6 DM Mono 9px `#9795B5`; the marker
  is a 10×2px bar in **ink `#232324`** (was accent) at `top: (1 - washFraction) * 100%`.
  Flow: DM Mono 15px / line-height 2, padding `20px 20px 176px`. Prompt tokens `#9795B5`;
  committed tokens `#232324` on their red tint; `<eos>` renders " ¶" + line break in
  `rgba(35,35,36,0.35)`. Caret: 2px × 1.15em, ink, 1.1s step blink.
- **CandidateList**: 176px wide, mounted **only when `candidates.length > 0`**, positioned at
  `left: clamp(caret.offsetLeft, 0, flow.clientWidth - 196)`, `top: caret.offsetTop + 34`.
  White, 1px `#D4D2E3`, radius 6px, the lavender shadow, overflow hidden. Rows: DM Mono 12px,
  padding `4px 10px`, 1px `#D4D2E3` divider; 10px dot; label opacity `0.45 + 0.55 * p/maxP`;
  winner row tinted red 10% with a red ↵.
- **Hover readout**: bottom-right, `rgba(255,255,255,0.92)`, 1px `#D4D2E3`, radius 4px,
  DM Mono 10px tabular `#232324`. Unchanged content.
- **ControlSentence**: 15px/1.75 `#232324`. Scrub numbers are DM Mono, tabular, **`#E61E25`**
  with a 1px dashed `rgba(230,30,37,0.55)` underline, `cursor: ew-resize`. Trailing hint now
  reads *"Drag the red numbers."* (was "blue"). Key `<code>` `#9795B5`; "(new key)" red.
- **Figcaption**: 12.5px/1.6 `#9795B5`. Second clause now reads *"…unwashed lavender could be
  anyone's text; deep red is this key's signature."*
- **TryThis**: h2 22px/700 `#1D1D40`. **No bullets** — the three items are rows in a
  `grid-template-columns: 36px 1fr` with a 12px gap, each preceded by a 1px `#D4D2E3` top rule
  and 16px vertical padding. The left cell holds a DM Mono 12px `#9795B5` index (01 / 02 / 03);
  the right cell is a 15px/1.75 `#232324` paragraph. Inline buttons red with dotted underlines.
  Copy unchanged.

### 2. Explainer (`#/explainer`, `src/pages/Explainer.tsx`)
Structure and copy unchanged. Restyle only: kicker `#9795B5`; h1 34px/700 `#1D1D40`;
section h2 18px/700 `#1D1D40`; body 15px/1.75 `#232324`. **References carry no bullets** —
each is a 14px/1.6 `#9795B5` paragraph with a 1px `#D4D2E3` top rule and 10px vertical padding.
Footnote 12px `#9795B5` above a 1px `#D4D2E3` rule.

### 3. Shell (`src/App.tsx`)
- **Header**, `items-center` (was `items-baseline`): the bead mark (34×40px) + wordmark
  "watermark" in Brockmann 700 20px `#1D1D40` with ".how" in `#E61E25`. Replaces the
  `llm-watermark` mono link. 12px gap, links to `#/`.
- **Nav**: DM Mono 12px, active `#E61E25`, inactive `#9795B5` hover `#E61E25`. Unchanged.
- **Footer**: new first line — the 9x-tinted bead (14×16px) + DM Mono 12px `#232324`
  *"by The 9x Academic"* with "9x" in red, linking to `https://the9x.ac`. The existing
  attribution line follows, 11px `#9795B5`, links underlined in `#D4D2E3`.
- **`<title>`**: "How does AI watermarking work? — watermark.how"
- **meta description**: "An interactive explainer on AI text watermarking: generate text from a
  live language model, watch the cryptographic evidence accumulate token by token, and see why
  detection power is bought with entropy. Relevant to the EU AI Act's marking obligation."

---

## Interactions & behaviour
Unchanged from the repo: rAF loop at `1000/speed` ms per step; temperature and speed apply
live; key, k, prompt or model changes reset the run; 500-token cap; scrub numbers drag on
pointer move and step on arrow keys; hover a token for its r / p / −ln(1−r).

## State
Unchanged: `model`, `modelError`, `k`, `temperature`, `keyHex`, `speed`, `prompt` in `Demo`;
`tokens`, `candidates`, `result`, `running` in `useGeneration`; `hover` and list position in
`GenerationPane`.

## Assets
- `assets/mark.svg` — koren.dev bead emblem, red `#E61E25` + light grey `#D4D2E3`, geometry
  lifted verbatim from the design system's `assets/logos/logo-koren-dev.svg`.
- `assets/mark-9x.svg` — same geometry, The 9x Academic tint (lavender `#9795B5` + red).
- `fonts/brockmann-*.woff2` — Brockmann, self-hosted, from the Coded Thinking design system.
- Favicon in `index.html` still carries the old blue scribble; swap it for the bead.

## Files in this bundle
| File | What |
|---|---|
| `Watermark Demo.dc.html` | the full prototype — both routes, all styling, the reference |
| `watermark.js` | standalone port of `src/lib/*` so the prototype runs; **not for merge** |
| `assets/`, `fonts/` | the assets listed above |

## Open items
- The prototype falls back to a tiny built-in trigram model because `public/model.json` is
  produced by `npm run build:model`; in the app nothing changes here.
- H1 and the EU AI Act paragraph are new copy written for this reskin — worth a read before merge.
